export class Movie {
	id: number;
	name: string;
	URL: string;

	constructor(id: number, name: string, URL: string) {
		this.id = id;
		this.name = name;
		this.URL = URL;
	}
} 