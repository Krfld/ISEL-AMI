import { Movie } from './Movie';

export const MOVIES: Movie[] = [
	{ id: 11, name: 'Avatar', URL: 'https://www.youtube.com/embed/6ziBFh3V1aM' },
	{ id: 12, name: 'Divergent', URL: 'https://www.youtube.com/embed/sutgWjz10sM' },
	{ id: 13, name: 'Inception', URL: 'https://www.youtube.com/embed/YoHD9XEInc0' },
	{ id: 14, name: 'Star Wars', URL: '"https://www.youtube.com/embed/FDXmcZ1_D- o' },
	{ id: 15, name: 'Ready Player One', URL: 'https://www.youtube.com/embed/ cSp1dM2Vj48' },
	{ id: 16, name: 'Matrix', URL: 'https://www.youtube.com/embed/vKQi3bBA1y8' },
	{ id: 17, name: 'The Revenant', URL: 'https://www.youtube.com/embed/LoebZZ8K5N0' },
	{ id: 18, name: 'American Hustle', URL: 'https://www.youtube.com/embed/ ST7a1aK_lG0' },
	{ id: 19, name: 'The Hunger Games', URL: 'https://www.youtube.com/embed/ mfmrPu43DF8' },
	{ id: 20, name: 'The Accountant', URL: 'https://www.youtube.com/embed/DBfsgcswlYQ' }
];