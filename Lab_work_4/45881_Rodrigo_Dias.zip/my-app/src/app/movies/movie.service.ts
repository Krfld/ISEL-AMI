import { Injectable } from '@angular/core';
import { Movie } from '../Movie';
import { MOVIES } from '../Movies';
import { Observable, of } from 'rxjs';
import { MessageService } from '../messages/message.service';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  getMovie(id: number): Observable<Movie | undefined> {
    this.messageService.add(`MovieService: fetched movie id=$
{id}`);
    return of(MOVIES.find(movie => movie.id === id));
  }

  constructor(private messageService: MessageService) { }
}
