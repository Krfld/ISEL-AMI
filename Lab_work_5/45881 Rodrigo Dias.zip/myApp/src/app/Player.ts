export class Player {
	name: string;
	description: string;
	image: string;
	followers: number;
	trophies: number;
	url: string;
}